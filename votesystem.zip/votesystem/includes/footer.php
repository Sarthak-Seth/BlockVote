<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2022s <a href="https://github.com/Sarthak-Seth">Group 256</a></strong>
    </div>
    <!-- /.container -->
</footer>